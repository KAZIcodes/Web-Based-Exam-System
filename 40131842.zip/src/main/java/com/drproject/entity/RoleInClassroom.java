package com.drproject.entity;

public enum RoleInClassroom {
    TEACHER, ADMIN, STUDENT
}

// Not a spring entity