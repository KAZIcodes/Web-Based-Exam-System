package com.drproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DrprojectApplicationTests {

    @Test
    void contextLoads() {
    }

}
